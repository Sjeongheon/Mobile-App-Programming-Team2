package com.example.t2

class WeatherInfo {
    var RainRate = ""
    var RainType = ""
    var Temperature = ""
    var Humidity = ""
    var PredictTime = ""
    var WindSpeed = ""
}